package com.filatov;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(SerenityRunner.class)
public class Tests{
    @Steps
    StepsForSerenity stepsForSerenity;

    @Test
    public void test() {
        stepsForSerenity.a_user_visit_a_page("https://pn.com.ua");
        stepsForSerenity.when_user_chooses_sofas_category();
        stepsForSerenity.producer_of_goods_equals_to_selected_producer("AMF");
    }
}