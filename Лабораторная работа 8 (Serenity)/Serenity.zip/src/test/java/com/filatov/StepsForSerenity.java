package com.filatov;

import net.thucydides.core.annotations.Step;
import org.assertj.core.api.Assertions;
import org.assertj.core.api.Condition;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class StepsForSerenity {
    public WebDriver driver;
    public HomePage homePage;
    public SofasPage sofasPage;
    public String pageSite = "https://pn.com.ua/";

    @Step ("The user visit a page {0}")
    public void a_user_visit_a_page (String page){
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        driver = new ChromeDriver();
        homePage = new HomePage(driver);
        driver.get(pageSite);

    }

    @Step ("When the user chooses category Sofas {0}")
    public void when_user_chooses_sofas_category(){
        sofasPage = homePage.choiceSofas();
    }

    @Step ("Producers of current goods equals to {0}")
    public void producer_of_goods_equals_to_selected_producer(String producer){
        List<String> sofasNames = sofasPage.getSofasNames();
        assertThat(sofasNames).areExactly(sofasNames.size(), new Condition<String>() {
            @Override
            public boolean matches(String s) {
                return s.startsWith(producer);
            }
        });

        driver.quit();
    }
}
